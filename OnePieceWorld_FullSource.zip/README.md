# OnePieceWorld Plugin

Features:
- Devil Fruit system (1 per player)
- 10-minute random fruit events
- Water damage for Devil Fruit users
- Bounty and Honor system with Vault economy support
- LuckPerms compatible
- Multiverse Core support
- No PlaceholderAPI dependency
