package com.onepieceworld.plugin;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Collections;
import java.util.List;

public class DevilFruitEventTask {
    public static void startTask(JavaPlugin plugin) {
        new BukkitRunnable() {
            @Override
            public void run() {
                List<? extends Player> players = Bukkit.getOnlinePlayers().stream().toList();
                if (players.size() < 3) return;
                Collections.shuffle(players);
                Bukkit.broadcastMessage("§6DF EVENT IS Happening");
                for (int i = 0; i < 3; i++) {
                    FruitManager.giveFruit(players.get(i));
                }
            }
        }.runTaskTimer(plugin, 0, 20 * 60 * 10); // every 10 minutes
    }
}