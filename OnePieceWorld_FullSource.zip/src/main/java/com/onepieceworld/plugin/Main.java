package com.onepieceworld.plugin;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    private static Main instance;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        FruitManager.init(this);
        BountyManager.init(this);
        DevilFruitEventTask.startTask(this);
        getServer().getPluginManager().registerEvents(new WaterDamageListener(), this);
        getLogger().info("OnePieceWorld plugin enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("OnePieceWorld plugin disabled!");
    }

    public static Main getInstance() {
        return instance;
    }
}