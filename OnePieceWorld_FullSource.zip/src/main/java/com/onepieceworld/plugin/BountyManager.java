package com.onepieceworld.plugin;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.util.*;

public class BountyManager {
    private static Map<UUID, Double> bounties = new HashMap<>();
    private static Economy economy;

    public static void init(JavaPlugin plugin) {
        if (Bukkit.getServer().getPluginManager().getPlugin("Vault") != null) {
            economy = plugin.getServer().getServicesManager().getRegistration(Economy.class).getProvider();
        }
    }

    public static void addBounty(Player player, double amount) {
        bounties.put(player.getUniqueId(), getBounty(player) + amount);
        if (economy != null) economy.depositPlayer(player, amount);
    }

    public static double getBounty(Player player) {
        return bounties.getOrDefault(player.getUniqueId(), 0.0);
    }
}