package com.onepieceworld.plugin;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import java.util.*;

public class FruitManager {
    private static Set<UUID> fruitUsers = new HashSet<>();

    public static void init(JavaPlugin plugin) {}

    public static boolean hasFruit(Player player) {
        return fruitUsers.contains(player.getUniqueId());
    }

    public static void giveFruit(Player player) {
        if (!hasFruit(player)) {
            fruitUsers.add(player.getUniqueId());
            player.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE));
            player.sendMessage("You have received a Devil Fruit!");
        }
    }
}